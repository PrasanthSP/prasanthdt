package com.social.oats.dao;

import java.util.List;

import com.social.oats.model.Post;

public interface PostDao {
	
	public List<Post> list();

	public Post get(String postBody);  

	public void merge(Post post);
	
	public void delete(String postBody);

} 
