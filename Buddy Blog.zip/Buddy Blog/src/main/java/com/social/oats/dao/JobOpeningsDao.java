package com.social.oats.dao;

import java.util.List;

import com.social.oats.model.JobOpenings;

public interface JobOpeningsDao {
	public List<JobOpenings> list();

	public JobOpenings get(String jobId);   

	public void merge(JobOpenings jobOpenings);
	
	public void delete(String jobId);

}
