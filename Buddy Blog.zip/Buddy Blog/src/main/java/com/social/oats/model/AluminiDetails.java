package com.social.oats.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotEmpty;
import com.social.oats.model.User;



@Entity
@Table(name="AluminiDetails")
public class AluminiDetails {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private String aluminiDetailsId;
	@ManyToOne
	private User user;
    @JoinColumn(name="username", nullable = false, updatable = false, insertable = false)
    @NotEmpty(message = "The username must not be empty")
	private String username;
	
    @JoinColumn(name="userEmail", nullable = false, updatable = false, insertable = false)
	@NotEmpty(message = "The userEmail must not be empty")
	private String userEmail;
	
    @JoinColumn(name="userMobile", nullable = false, updatable = false, insertable = false)
	@NotEmpty(message = "The userMobile must not be empty")
	private String userMobile;
	
    @JoinColumn(name="password", nullable = false, updatable = false, insertable = false)
	@NotEmpty(message = "The password must not be empty")
	private String password;
	@NotEmpty(message = "The aluminiBirthdate must not be empty")
	private String aluminiBirthdate;
	@NotEmpty(message = "The aluminiCompany must not be empty")
	private String aluminiCompany;
	@NotEmpty(message = "The aluminiCity must not be empty")
	private String aluminiCity;
	@NotEmpty(message = "The aluminiProfile must not be empty")
	private String aluminiProfile;
	@NotEmpty(message = "The aluminiRegno must not be empty")
	private String aluminiRegno;
	public String getAluminiDetailsId() {
		return aluminiDetailsId;
	}
	public void setAluminiDetailsId(String aluminiDetailsId) {
		this.aluminiDetailsId = aluminiDetailsId;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getUserEmail() {
		return userEmail;
	}
	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}
	public String getUserMobile() {
		return userMobile;
	}
	public void setUserMobile(String userMobile) {
		this.userMobile = userMobile;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getAluminiBirthdate() {
		return aluminiBirthdate;
	}
	public void setAluminiBirthdate(String aluminiBirthdate) {
		this.aluminiBirthdate = aluminiBirthdate;
	}
	public String getAluminiCompany() {
		return aluminiCompany;
	}
	public void setAluminiCompany(String aluminiCompany) {
		this.aluminiCompany = aluminiCompany;
	}
	public String getAluminiCity() {
		return aluminiCity;
	}
	public void setAluminiCity(String aluminiCity) {
		this.aluminiCity = aluminiCity;
	}
	public String getAluminiProfile() {
		return aluminiProfile;
	}
	public void setAluminiProfile(String aluminiProfile) {
		this.aluminiProfile = aluminiProfile;
	}
	public String getAluminiRegno() {
		return aluminiRegno;
	}
	public void setAluminiRegno(String aluminiRegno) {
		this.aluminiRegno = aluminiRegno;
	}
	
	
	
}
