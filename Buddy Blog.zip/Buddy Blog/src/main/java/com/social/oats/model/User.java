package com.social.oats.model;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="OatsUser") 
public class User {  
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private String userId;
	@NotEmpty(message = "The username must not be empty")
    private String username;
	@NotEmpty(message = "The userEmail must not be empty")
    private String userEmail;
	@NotEmpty(message = "The userMobile must not be empty")
    private String userMobile;
	@NotEmpty(message = "The password must not be empty")
    private String password;
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getUsername() {
		return username; 
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getUserEmail() {
		return userEmail;
	}
	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}
	public String getUserMobile() {
		return userMobile;
	}
	public void setUserMobile(String userMobile) {
		this.userMobile = userMobile;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	

}
