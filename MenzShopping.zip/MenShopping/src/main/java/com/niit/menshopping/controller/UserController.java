package com.niit.menshopping.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.niit.menshopping.dao.UserDAO;


@Controller
public class UserController {

   @Autowired
	UserDAO userDAO;


	@RequestMapping("/isValidUser")
	public ModelAndView showMessage(@RequestParam(value = "name") String name,
			@RequestParam(value = "password") String password) {
		System.out.println("in controller");

		String message;
		ModelAndView mv ;
		
		if ((String) userDAO.isValidUser(name, password)=="user") 
		{
			message = "Successfully Logged in";
			 mv = new ModelAndView("login");
		} else if(userDAO.isValidUser(name,password)=="admin") {
			message = "";
			 mv = new ModelAndView("admin");
		}else{
			message="username or password mismatch ";
			mv=new ModelAndView("signin");
		}

		//ModelAndView mv = new ModelAndView("success");
		mv.addObject("message", message);
		mv.addObject("name", name);
		// mv.addObject("password", password);
		return mv;
	}

}
