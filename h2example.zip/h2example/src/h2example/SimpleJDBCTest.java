package h2example;
import java.sql.*; 
public class SimpleJDBCTest { 
   public static void main(String[] args) throws ClassNotFoundException {
       String url = "jdbc:h2:tcp://localhost/~/test";
       String username = "sa"; 
       String password = "";
       String query = "SELECT * FROM SHOPPING ";
       
       Class.forName("org.h2.Driver");
       
       try (Connection con = DriverManager.getConnection(url, username, password);
            Statement stmt = con.createStatement ();
            ResultSet rs = stmt.executeQuery (query)) {
          
    	   while (rs.next()) {
            
    		   int ID = rs.getInt("ID");
             String PRODUCT_NAME  = rs.getString("PRODUCT_NAME");
             String SELLER_NAME = rs.getString("SELLER_NAME");
             int STOCK = rs.getInt("STOCK");
           
             System.out.println("ID:" + ID + "\n"+ "Product Name: " + PRODUCT_NAME +  "\n"
             + "Seller Name: "+ SELLER_NAME + "\n"+ "Stock:" + STOCK);
         
    	   } // end of while
     
       }
       catch (SQLException e)
       {
         System.out.println("SQL Exception: " + e);
     } // end of try-with-resources
  } }
