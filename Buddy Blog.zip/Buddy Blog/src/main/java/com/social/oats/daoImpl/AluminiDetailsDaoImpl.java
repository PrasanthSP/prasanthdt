package com.social.oats.daoImpl;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.social.oats.dao.AluminiDetailsDao;
import com.social.oats.model.AluminiDetails;


@Repository("aluminiDetailsDao")
public class AluminiDetailsDaoImpl implements AluminiDetailsDao{
	
	@Autowired
	private SessionFactory sessionFactory;


	public AluminiDetailsDaoImpl(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Transactional
	public List<AluminiDetails> list() {
		@SuppressWarnings("unchecked")
		List<AluminiDetails> list = (List<AluminiDetails>) sessionFactory.getCurrentSession()
				.createCriteria(AluminiDetails.class)
				.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();

		return list;
	}

	@Transactional
	public void merge(AluminiDetails aluminiDetails) {
		sessionFactory.getCurrentSession().merge(aluminiDetails);
	}
	

	@Transactional
	public void delete(String aluminiRegno) {
		AluminiDetails aluminiDetails = new AluminiDetails();
		aluminiDetails.setAluminiRegno(aluminiRegno);
		sessionFactory.getCurrentSession().delete(aluminiDetails);
	}

	@Transactional
	public AluminiDetails get(String aluminiRegno) {
		String hql = "from AluminiDetails where aluminiRegno=" + "'"+ aluminiRegno+"'";
		Query query = sessionFactory.getCurrentSession().createQuery(hql);
		
		@SuppressWarnings("unchecked")
		List<AluminiDetails> list = (List<AluminiDetails>) query.list();
		
		if (list != null && !list.isEmpty()) {
			return list.get(0);
		}
		
		return null; 
	}

	
 
} 
