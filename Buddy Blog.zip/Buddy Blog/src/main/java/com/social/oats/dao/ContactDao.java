package com.social.oats.dao;

import java.util.List;

import com.social.oats.model.Contact;

public interface ContactDao {
	
	public List<Contact> list();

	public Contact get(String contactQueryno);  

	public void merge(Contact contact);
	
	public void delete(String contactQueryno);

} 
