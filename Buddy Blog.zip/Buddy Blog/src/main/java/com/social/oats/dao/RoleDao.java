package com.social.oats.dao;

import java.util.List;

import com.social.oats.model.Role;

public interface RoleDao {
	public List<Role> list();

	public Role get(String roleAssigned);  

	public void merge(Role role);
	
	public void delete(String roleAssigned);

}
