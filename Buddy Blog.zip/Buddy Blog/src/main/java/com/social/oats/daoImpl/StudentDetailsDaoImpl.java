package com.social.oats.daoImpl;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.social.oats.dao.StudentDetailsDao;
import com.social.oats.model.StudentDetails;

@Repository("studentDetailsDao")
public class StudentDetailsDaoImpl implements StudentDetailsDao{
	
	@Autowired
	private SessionFactory sessionFactory;


	public StudentDetailsDaoImpl(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Transactional
	public List<StudentDetails> list() {
		@SuppressWarnings("unchecked")
		List<StudentDetails> list = (List<StudentDetails>) sessionFactory.getCurrentSession()
				.createCriteria(StudentDetails.class)
				.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();

		return list;
	}

	@Transactional
	public void merge(StudentDetails studentDetails) {
		sessionFactory.getCurrentSession().merge(studentDetails);
	}
	

	@Transactional
	public void delete(String studentRegno) {
		StudentDetails studentDetails = new StudentDetails();
		studentDetails.setStudentRegno(studentRegno);
		sessionFactory.getCurrentSession().delete(studentDetails);
	}

	@Transactional
	public StudentDetails get(String studentRegno) {
		String hql = "from StudentDetails where studentRegno=" + "'"+ studentRegno+"'";
		Query query = sessionFactory.getCurrentSession().createQuery(hql);
		
		@SuppressWarnings("unchecked")
		List<StudentDetails> list = (List<StudentDetails>) query.list();
		
		if (list != null && !list.isEmpty()) {
			return list.get(0);
		}
		
		return null; 
	}


}
