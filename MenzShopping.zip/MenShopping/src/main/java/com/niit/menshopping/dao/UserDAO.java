package com.niit.menshopping.dao;


	import org.springframework.stereotype.Repository;

	@Repository
	public class UserDAO {
		

		
		public String isValidUser(String userName, String password)
		{
			if(userName.equals("candy")  && password.equals("NIIT")	)
			{
			
			
				return "user";
			}
			else if(userName.equals("Prasanth")&& password.equals("candy"))
			{
				
				
				return "admin";
			}
			else
			{
			
	
				return "none";
			}
		}
		




	}

