package com.social.oats.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotEmpty;
import com.social.oats.model.User;

@Entity
@Table(name="EmployeeDetails")
public class EmployeeDetails {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private String employeeDetailsId;
	@ManyToOne
	private User user;
    @JoinColumn(name="username", nullable = false, updatable = false, insertable = false)
   	
	@NotEmpty(message = "The username must not be empty")
	private String username;
	
    @JoinColumn(name="userEmail", nullable = false, updatable = false, insertable = false)
	@NotEmpty(message = "The userEmail must not be empty")
	private String userEmail;
	
    @JoinColumn(name="userMobile", nullable = false, updatable = false, insertable = false)
	@NotEmpty(message = "The userMobile must not be empty")
	private String userMobile;
	 
    @JoinColumn(name="password", nullable = false, updatable = false, insertable = false)
	@NotEmpty(message = "The password must not be empty")
	private String password;
	@NotEmpty(message = "The employeeBirthdate must not be empty")
	private String employeeBirthdate;
	@NotEmpty(message = "The employeeDepartment must not be empty")
	private String employeeDepartment;
	@NotEmpty(message = "The employeeCity must not be empty")
	private String employeeCity;
	@NotEmpty(message = "The employeeProfile must not be empty")
	private String employeeProfile;
	@NotEmpty(message = "The employeeRegno must not be empty")
	private String employeeRegno;
	public String getEmployeeDetailsId() {
		return employeeDetailsId;
	}
	public void setEmployeeDetailsId(String employeeDetailsId) {
		this.employeeDetailsId = employeeDetailsId;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getUserEmail() {
		return userEmail;
	}
	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}
	public String getUserMobile() {
		return userMobile;
	}
	public void setUserMobile(String userMobile) {
		this.userMobile = userMobile;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getEmployeeBirthdate() {
		return employeeBirthdate;
	}
	public void setEmployeeBirthdate(String employeeBirthdate) {
		this.employeeBirthdate = employeeBirthdate;
	}
	public String getEmployeeDepartment() {
		return employeeDepartment;
	}
	public void setEmployeeDepartment(String employeeDepartment) {
		this.employeeDepartment = employeeDepartment;
	}
	public String getEmployeeCity() {
		return employeeCity;
	}
	public void setEmployeeCity(String employeeCity) {
		this.employeeCity = employeeCity;
	}
	public String getEmployeeProfile() {
		return employeeProfile;
	}
	public void setEmployeeProfile(String employeeProfile) {
		this.employeeProfile = employeeProfile;
	}
	public String getEmployeeRegno() {
		return employeeRegno;
	}
	public void setEmployeeRegno(String employeeRegno) {
		this.employeeRegno = employeeRegno;
	}
	
	
} 
