package com.niit.menshopping.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
//import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
//import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.niit.menshopping.dao.UserDetailsDAO;
import com.niit.menshopping.model.UserDetails;




@Controller
public class RegistrationController {
	
	
	@Autowired
	private UserDetailsDAO userDetailsDAO;
	
	
	
	@RequestMapping(value = "/getuserDetail", method = RequestMethod.GET)
	public String listCategorys(Model model) {
		model.addAttribute("userDetails", new UserDetails());
		model.addAttribute("userDetails", this.userDetailsDAO.list());
		//model.addAttribute("clickedCategories","true");
		return "admin";
	}
	
	

	@RequestMapping(value="userdetails") 
	public ModelAndView addsCategory(@ModelAttribute UserDetails userdetails)
	{
		
		userDetailsDAO.save(userdetails);		
		List<UserDetails> userDetails = userDetailsDAO.list();
		ModelAndView mv = new ModelAndView("confirmDetails");
		mv.addObject("userDetails", userDetails);
		return mv ;
	}}
	
	//For add and update category both
	/*@RequestMapping(value= "/userdetails", method = RequestMethod.POST)
	public String adduserdetails(@ModelAttribute("userDetails") UserDetails userDetails){
		System.out.println("in Userdetails");
	
		userDetailsDAO.saveOrUpdate(userDetails);
		
		return "redirect:/home.jsp";
		
	}}*/
	
	/*@RequestMapping("category/remove/{id}")
    public String deleteCategory(@PathVariable("id") String id,ModelMap model) throws Exception{
		
       try {
		categoryDAO.delete(id);
		model.addAttribute("message","Successfully Added");
	} catch (Exception e) {
		model.addAttribute("message",e.getMessage());
		e.printStackTrace();
	}
       //redirectAttrs.addFlashAttribute(arg0, arg1)
        return "redirect:/categories";
    }
 
    @RequestMapping("category/edit/{id}")
    public String editCategory(@PathVariable("id") String id, Model model){
    	System.out.println("editCategory");
        model.addAttribute("category", this.categoryDAO.get(id));
        model.addAttribute("listCategorys", this.categoryDAO.list());
        return "category";
    }
	}*/


