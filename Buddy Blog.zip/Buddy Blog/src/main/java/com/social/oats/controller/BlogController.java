package com.social.oats.controller;

public class BlogController {

}
