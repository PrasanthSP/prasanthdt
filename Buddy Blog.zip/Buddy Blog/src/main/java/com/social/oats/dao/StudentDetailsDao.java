package com.social.oats.dao;

import java.util.List;

import com.social.oats.model.StudentDetails;

public interface StudentDetailsDao {
	
	public List<StudentDetails> list();

	public StudentDetails get(String studentRegno);  

	public void merge(StudentDetails studentDetails);
	
	public void delete(String studentRegno);

}
