package com.niit.menshopping.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.niit.menshopping.dao.UserDAO;
import com.niit.menshopping.model.User;

@Controller
public class UserController {

   @Autowired
	UserDAO userDAO;


	@RequestMapping("/isValidUser")
	public ModelAndView showMessage(@RequestParam(value = "username") String username,
			@RequestParam(value = "password") String password) {
		System.out.println("in controller");

		String message;
		ModelAndView mv ;
		
		if (userDAO.isValidUser(username,password)) 
		{
			message = "Successfully Logged in";
			 mv = new ModelAndView("admin");
		} else{
			message="username or password mismatch ";
			mv=new ModelAndView("signin");
		}

		mv.addObject("message", message);
		mv.addObject("username", username);
		return mv;
	}
	@RequestMapping("/register")
	public ModelAndView registerUser(@ModelAttribute User user) {
		System.out.println("in reg controller");
		ModelAndView mv;
		String msg;
		msg="register successfully";
		userDAO.saveOrUpdate(user);
	  
		mv= new ModelAndView("/signin");
		mv.addObject("msg",msg);
		return mv;
	 }

}
