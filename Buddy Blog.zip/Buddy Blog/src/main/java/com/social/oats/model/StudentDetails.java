package com.social.oats.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotEmpty;
import com.social.oats.model.User;



@Entity
@Table(name="StudentDetails")
public class StudentDetails {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private String studentDetailsId;
	@ManyToOne
	private User user;
    @JoinColumn(name="username", nullable = false, updatable = false, insertable = false)
   	
	@NotEmpty(message = "The username must not be empty")
	private String username;
	
    @JoinColumn(name="userEmail", nullable = false, updatable = false, insertable = false)
	@NotEmpty(message = "The userEmail must not be empty")
	private String userEmail;
	
    @JoinColumn(name="userMobile", nullable = false, updatable = false, insertable = false)
	@NotEmpty(message = "The userMobile must not be empty")
	private String userMobile;
	
    @JoinColumn(name="password", nullable = false, updatable = false, insertable = false)
	@NotEmpty(message = "The password must not be empty")
	private String password;
	@NotEmpty(message = "The studentBirthdate must not be empty")
	private String studentBirthdate;
	@NotEmpty(message = "The studentCourse must not be empty")
	private String studentCourse;
	@NotEmpty(message = "The studentCity must not be empty")
	private String studentCity;
	@NotEmpty(message = "The studentRegno must not be empty")
	private String studentRegno;
	public String getStudentDetailsId() {
		return studentDetailsId;
	}
	public void setStudentDetailsId(String studentDetailsId) {
		this.studentDetailsId = studentDetailsId;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getUserEmail() {
		return userEmail;
	}
	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}
	public String getUserMobile() {
		return userMobile;
	}
	public void setUserMobile(String userMobile) {
		this.userMobile = userMobile;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getStudentBirthdate() {
		return studentBirthdate;
	}
	public void setStudentBirthdate(String studentBirthdate) {
		this.studentBirthdate = studentBirthdate;
	}
	public String getStudentCourse() {
		return studentCourse;
	}
	public void setStudentCourse(String studentCourse) {
		this.studentCourse = studentCourse;
	}
	public String getStudentCity() {
		return studentCity;
	}
	public void setStudentCity(String studentCity) {
		this.studentCity = studentCity;
	}
	public String getStudentRegno() {
		return studentRegno;
	}
	public void setStudentRegno(String studentRegno) {
		this.studentRegno = studentRegno;
	}
	

} 
