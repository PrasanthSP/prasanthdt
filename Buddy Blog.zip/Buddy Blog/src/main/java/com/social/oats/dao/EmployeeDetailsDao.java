package com.social.oats.dao;

import java.util.List;

import com.social.oats.model.EmployeeDetails;

public interface EmployeeDetailsDao {
	public List<EmployeeDetails> list();

	public EmployeeDetails get(String employeeRegno);  

	public void merge(EmployeeDetails employeeDetails);
	
	public void delete(String employeeRegno);

}
 