package userDAO;

public class Center {
	public boolean isValidCredentials (String UserID,String Password)
	{
if (UserID.equals("test")&&Password.equals("good00"))
{
	return true;
}
	
else{return false;}
	}
	}

