package com.social.oats.dao;

import java.util.List;

import com.social.oats.model.FriendRequest;

public interface FriendRequestDao {

	public List<FriendRequest> list();

	public FriendRequest get(String username);  

	public void merge(FriendRequest friendRequest);
	
	public void delete(String username);
}
