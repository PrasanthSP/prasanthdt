package com.social.oats.dao;

import java.util.List;

import com.social.oats.model.User;

public interface UserDao {
	
	public List<User> list();

	public User get(String username);  

	public void merge(User user);
	
	public void delete(String username);

}
