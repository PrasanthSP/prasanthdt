package com.social.oats.dao;

import java.util.List;

import com.social.oats.model.AluminiDetails;

public interface AluminiDetailsDao {
	
	public List<AluminiDetails> list();

	public AluminiDetails get(String aluminiRegno);  

	public void merge(AluminiDetails aluminiDetails);
	
	public void delete(String aluminiRegno);

} 
