package com.social.oats.daoImpl; 

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.social.oats.dao.JobOpeningsDao;
import com.social.oats.model.JobOpenings; 

@Repository("jobOpeningsDao")
public class JobOpeningsDaoImpl implements JobOpeningsDao{
	
	@Autowired
	private SessionFactory sessionFactory;


	public JobOpeningsDaoImpl(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Transactional
	public List<JobOpenings> list() {
		@SuppressWarnings("unchecked")
		List<JobOpenings> list = (List<JobOpenings>) sessionFactory.getCurrentSession()
				.createCriteria(JobOpenings.class)
				.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();

		return list;
	}

	@Transactional
	public void merge(JobOpenings jobOpenings) {
		sessionFactory.getCurrentSession().merge(jobOpenings);
	}
	

	@Transactional
	public void delete(String jobId) {
		JobOpenings jobOpenings = new JobOpenings();
		jobOpenings.setJobId(jobId);
		sessionFactory.getCurrentSession().delete(jobOpenings);
	}

	@Transactional
	public JobOpenings get(String jobId) {
		String hql = "from JobOpenings where jobId=" + "'"+ jobId+"'";
		Query query = sessionFactory.getCurrentSession().createQuery(hql);
		
		@SuppressWarnings("unchecked")
		List<JobOpenings> list = (List<JobOpenings>) query.list();
		
		if (list != null && !list.isEmpty()) {
			return list.get(0);
		}
		
		return null;
	}

}
