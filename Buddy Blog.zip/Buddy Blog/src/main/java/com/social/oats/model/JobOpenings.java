package com.social.oats.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotEmpty;
import com.social.oats.model.User;

@Entity
@Table(name="JobOpenings")
public class JobOpenings { 
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private String jobOpeningsId;
	@ManyToOne
	private User user;
    @JoinColumn(name="userId", nullable = false, updatable = false, insertable = false)
   	
	@NotEmpty(message = "The userId must not be empty")
	private String userId;
	@NotEmpty(message = "The companyName must not be empty")
	private String companyName;
	@NotEmpty(message = "The jobId must not be empty")
	private String jobId;
	@NotEmpty(message = "The jobProfile must not be empty")
	private String jobProfile;
	@NotEmpty(message = "The jobStatus must not be empty")
	private String jobStatus;
	@NotEmpty(message = "The jobDescription must not be empty")
	private String jobDescription;
	@NotEmpty(message = "The qualification must not be empty")
	private String qualification;
	@NotEmpty(message = "The experience must not be empty")
	private String experience;
	@NotEmpty(message = "The vacancies must not be empty")
	private String vacancies;
	@NotEmpty(message = "The jobLocation must not be empty")
	private String jobLocation;
	@NotEmpty(message = "The annualSalary must not be empty")
	private String annualSalary;
	public String getJobOpeningsId() {
		return jobOpeningsId;
	}
	public void setJobOpeningsId(String jobOpeningsId) {
		this.jobOpeningsId = jobOpeningsId;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	
	public String getJobId() {
		return jobId; 
	}
	public void setJobId(String jobId) {
		this.jobId = jobId;
	}
	public String getJobProfile() {
		return jobProfile;
	}
	public void setJobProfile(String jobProfile) {
		this.jobProfile = jobProfile;
	}
	
	public String getJobStatus() {
		return jobStatus;
	}
	public void setJobStatus(String jobStatus) {
		this.jobStatus = jobStatus;
	}
	public String getJobDescription() {
		return jobDescription;
	}
	public void setJobDescription(String jobDescription) {
		this.jobDescription = jobDescription;
	}
	public String getQualification() {
		return qualification;
	}
	public void setQualification(String qualification) {
		this.qualification = qualification;
	}
	public String getExperience() {
		return experience;
	}
	public void setExperience(String experience) {
		this.experience = experience;
	}
	public String getVacancies() {
		return vacancies;
	}
	public void setVacancies(String vacancies) {
		this.vacancies = vacancies;
	}
	public String getJobLocation() {
		return jobLocation;
	}
	public void setJobLocation(String jobLocation) {
		this.jobLocation = jobLocation;
	}
	public String getAnnualSalary() {
		return annualSalary;
	}
	public void setAnnualSalary(String annualSalary) {
		this.annualSalary = annualSalary;
	}
	
	

}
