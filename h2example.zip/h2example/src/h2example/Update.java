package h2example;


import java.sql.*;
 
public class Update {
 
    public static void main(String[] args) {
         
        Connection con;
        Statement stmt;
        try {
            
            con = DriverManager.getConnection("jdbc:h2:tcp://localhost/~/test", "sa", "");
            
            stmt = con.createStatement();
            stmt.execute("UPDATE SHOPPING SET STOCK=26 WHERE ID=2");

    
            System.out.println("Updated succesfully: ");
         } 
        catch (SQLException e) {
            e.printStackTrace();
        
        }
    }
}
