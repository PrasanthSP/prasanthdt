package com.social.oats.daoImpl;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.social.oats.dao.FriendsDao;
import com.social.oats.model.Friends;

@Repository("friendsDao")
public class FriendsDaoImpl implements FriendsDao{
	
	@Autowired
	private SessionFactory sessionFactory;


	public FriendsDaoImpl(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Transactional
	public List<Friends> list() {
		@SuppressWarnings("unchecked")
		List<Friends> list = (List<Friends>) sessionFactory.getCurrentSession()
				.createCriteria(Friends.class)
				.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();

		return list;
	}

	@Transactional
	public void merge(Friends friends) {
		sessionFactory.getCurrentSession().merge(friends);
	}
	

	@Transactional
	public void delete(String username) {
		Friends friends = new Friends();
		friends.setUsername(username);
		sessionFactory.getCurrentSession().delete(friends);
	}

	@Transactional
	public Friends get(String username) {
		String hql = "from Friends where username=" + "'"+ username+"'";
		Query query = sessionFactory.getCurrentSession().createQuery(hql);
		
		@SuppressWarnings("unchecked")
		List<Friends> list = (List<Friends>) query.list();
		
		if (list != null && !list.isEmpty()) {
			return list.get(0);
		}
		
		return null;
	}

} 
