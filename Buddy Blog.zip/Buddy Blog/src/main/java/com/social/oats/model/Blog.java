package com.social.oats.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotEmpty;
import com.social.oats.model.User;



@Entity
@Table(name="Blog")
public class Blog {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
    private String blogId;
	@NotEmpty(message = "The blogHead must not be empty")
    private String blogHead;
	@NotEmpty(message = "The blogBody must not be empty")
    private String blogBody;
	@NotEmpty(message = "The blogDate must not be empty")
    private String blogDate;
	@NotEmpty(message = "The userId must not be empty")
	@ManyToOne
	private User user;
    @JoinColumn(name="userId", nullable = false, updatable = false, insertable = false)
    @NotEmpty(message = "The userId must not be empty")
    private String userId;

	public String getBlogId() {
		return blogId;
	}

	public void setBlogId(String blogId) {
		this.blogId = blogId;
	}

	public String getBlogHead() {
		return blogHead;
	}

	public void setBlogHead(String blogHead) {
		this.blogHead = blogHead;
	}

	public String getBlogBody() {
		return blogBody;
	}

	public void setBlogBody(String blogBody) {
		this.blogBody = blogBody;
	}

	public String getBlogDate() {
		return blogDate;
	}

	public void setBlogDate(String blogDate) {
		this.blogDate = blogDate;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	

}
