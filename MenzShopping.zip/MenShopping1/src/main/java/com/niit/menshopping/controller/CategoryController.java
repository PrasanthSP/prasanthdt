package com.niit.menshopping.controller;


import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.niit.menshopping.dao.CategoryDAO;
import com.niit.menshopping.model.Category;



@Controller
public class CategoryController {

	@Autowired
	private CategoryDAO categoryDAO;
	
	@RequestMapping("addCategory")
	public ModelAndView addCatey()
	{
		System.out.println("in add view cat");
		List<Category> categoryList = categoryDAO.list();
		ModelAndView mv = new ModelAndView("/addCategory");
		mv.addObject("addCategory", categoryList);
		return mv;
	  	 }
	
	@RequestMapping(value="addsCategory") 
	public ModelAndView addsCategory(@ModelAttribute Category category)
	{
		
		categoryDAO.saveOrUpdate(category);		
		List<Category> categoryList = categoryDAO.list();
		ModelAndView mv = new ModelAndView("categoryList");
		mv.addObject("categoryList", categoryList);
		return mv ;
	}
	@RequestMapping(value="updateCategory") 
	public ModelAndView updateCategory(@ModelAttribute Category category)
	{
		System.out.println("in upt cat");
		categoryDAO.update(category);		
		List<Category> categoryList = categoryDAO.list();
		ModelAndView mv = new ModelAndView("/categoryList");
		mv.addObject("categoryList", categoryList);
		return mv ;
	}
	@RequestMapping("categorylist")
	public ModelAndView addCate()
	{
		System.out.println("in  view cat");
		//categoryDAO.saveOrUpdate(category);
	  return new ModelAndView("categoryList");
	 }
	
	@RequestMapping(value="deleteCategory",method = RequestMethod.GET) 
	public ModelAndView deleteCategory(@RequestParam("delete") String StringId) {
		System.out.println("delete category successfully");
		categoryDAO.delete(StringId);
		List<Category> categoryList = categoryDAO.list();
		ModelAndView mv = new ModelAndView("/categoryList");
		mv.addObject("categoryList", categoryList);
		return mv;
	 }

	@RequestMapping("getAllCategories")
	public ModelAndView getAllCategories() {

		System.out.println("getAllCategories");
		
		List<Category> categoryList = categoryDAO.list();
		
		ModelAndView mv = new ModelAndView("/categoryList");
		mv.addObject("categoryList", categoryList);

		return mv;
	}
	@RequestMapping("getAlCategories")
	public ModelAndView getAlCategories() {

		System.out.println("getAlCategories");
		
		List<Category> categoryList = categoryDAO.list();
		
		ModelAndView mv = new ModelAndView("/updateCategory");
		mv.addObject("updateCategory", categoryList);

		return mv;
	}
	
	

}

