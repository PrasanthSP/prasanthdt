package h2example;
import java.sql.*;

public class Insert {


	


	   public static void main(String[] args) {
	       Connection connection;
	       Statement stmt ;
	       try
	       {
	           Class.forName("org.h2.Driver");
	           connection = DriverManager
	               .getConnection("jdbc:h2:tcp://localhost/~/test", "sa", "");
	            
	           stmt = connection.createStatement();
	           stmt.execute("INSERT INTO SHOPPING (ID,PRODUCT_NAME,SELLER_NAME,STOCK)"
	           + "VALUES (114,'XYZ','ZZZ','19')");
	           System.out.println("success");
	       } 
	       catch (Exception e) {
	           e.printStackTrace();
	       }finally {
	           try {
	         
	           } catch (Exception e) {
	               e.printStackTrace();
	           }
	       }
	   }
	}



