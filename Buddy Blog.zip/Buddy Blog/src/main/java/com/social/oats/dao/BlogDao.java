package com.social.oats.dao;

import java.util.List;

import com.social.oats.model.Blog;

public interface BlogDao {
	public List<Blog> list();

	public Blog get(String blogHead);  

	public void merge(Blog blog);
	
	public void delete(String blogHead);

} 
